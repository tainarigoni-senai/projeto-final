package enumeration;

public enum Funcionalidade {
    LISTAR, CADASTRAR, ALTERAR, EXCLUIR;
}
