package dao;

import connection.ConexaoMySQL;
import exception.FuncionarioException;
import exception.PessoaException;
import model.Funcionario;
import model.Pessoa;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;

public class FuncionarioDAO {

    //Métodos de Interação

    public ArrayList<Funcionario> selecionar() throws FuncionarioException, ParseException {
        try {
            String sql = "SELECT " +
                    "f.id, " +
                    "f.cargo, " +
                    "f.salario, " +
                    "f.id_pessoa, " +
                    "p.nome_completo, " +
                    "p.data_nascimento, " +
                    "p.documento, " +
                    "p.pais, " +
                    "p.estado, " +
                    "p.cidade " +
                    "FROM funcionario f " +
                    "JOIN pessoa p ON p.id = f.id_pessoa";

            Statement declaracao = ConexaoMySQL.get().createStatement();
            ResultSet resultado = declaracao.executeQuery(sql);

            ArrayList<Funcionario> funcionarios = new ArrayList<>();
            while (resultado.next()) {
                Funcionario funcionario = new Funcionario(
                        resultado.getLong("id"),
                        resultado.getString("nome_completo"),
                        resultado.getDate("data_nascimento").toLocalDate(),
                        resultado.getString("documento"),
                        resultado.getString("pais"),
                        resultado.getString("estado"),
                        resultado.getString("cidade"),
                        resultado.getLong("id_pessoa"),
                        resultado.getString("cargo"),
                        resultado.getDouble("salario")
                );
                funcionarios.add(funcionario);
            }
            return funcionarios;

        } catch (SQLException e) {
            throw new FuncionarioException("Erro desconhecido! Por favor, tente novamente mais tarde.");
        }
    }

    public Boolean deletar(Long id) throws FuncionarioException {
        try {
            String sql = "DELETE FROM funcionario WHERE id = ? ";
            PreparedStatement preparacao = ConexaoMySQL.get().prepareStatement(sql);
           preparacao.setLong(1, id);
            return preparacao.executeUpdate() > 0;
        } catch (Exception e) {
            throw new FuncionarioException("Erro desconhecido! Por favor, tente novamente mais tarde.");
        }

    }
    public Funcionario selecionarPorId(Long id) throws FuncionarioException {
        try {
            String sql = "SELECT " +
                    "f.id, " +
                    "f.cargo, " +
                    "f.salario, " +
                    "f.id_pessoa, " +
                    "p.nome_completo, " +
                    "p.data_nascimento, " +
                    "p.documento, " +
                    "p.pais, " +
                    "p.estado, " +
                    "p.cidade " +
                    "FROM funcionario f " +
                    "JOIN pessoa p ON p.id = f.id_pessoa";
            PreparedStatement preparacao = ConexaoMySQL.get().prepareStatement(sql);
            preparacao.setLong(1, id);
            ResultSet resultado = preparacao.executeQuery();

            if(resultado.next()) {
                return new Funcionario(
                        resultado.getLong("id"),
                        resultado.getString("nome_completo"),
                        resultado.getDate("data_nascimento").toLocalDate(),
                        resultado.getString("documento"),
                        resultado.getString("pais"),
                        resultado.getString("estado"),
                        resultado.getString("cidade"),
                        resultado.getLong("id_pessoa"),
                        resultado.getString("cargo"),
                        resultado.getDouble("salario")
                );
            } else {
                return null;
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new FuncionarioException("Erro desconhecido! Por favor, tente novamente mais tarde.");
        }
    }

}
