package controller;

import enumeration.Funcionalidade;
import exception.FuncionarioException;
import test.FuncionarioTest;

import java.text.ParseException;

public class FuncionarioController {

    // Atributos
    private FuncionarioTest funcionarioTest;

    // Construtor
    public FuncionarioController(FuncionarioTest funcionarioTest) {
        this.funcionarioTest = funcionarioTest;
    }

    // Gerenciador de testes
    public String testar(Funcionalidade funcionalidade) throws FuncionarioException, ParseException {
        switch (funcionalidade){
            case LISTAR :
                return funcionarioTest.listar();
            case CADASTRAR:
                return null;
            case ALTERAR:
                return null;
            case EXCLUIR:
                return funcionarioTest.excluir();
            default:
                return null;
        }
    }
}
