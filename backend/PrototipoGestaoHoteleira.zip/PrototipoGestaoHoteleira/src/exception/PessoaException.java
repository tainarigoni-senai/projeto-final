package exception;

public class PessoaException extends Exception {

    // Método para exceções
    public PessoaException(String mensagem) {
        super(mensagem);
    }

}
