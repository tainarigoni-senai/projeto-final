package exception;

public class FuncionarioException extends Exception {

    // Método para exceções
    public FuncionarioException(String mensagem) {
        super(mensagem);
    }


}
