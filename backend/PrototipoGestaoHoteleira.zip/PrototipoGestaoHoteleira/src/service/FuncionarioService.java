package service;

import dao.FuncionarioDAO;
import enumeration.Funcionalidade;
import exception.FuncionarioException;
import exception.PessoaException;
import model.Funcionario;
import util.Util;

import java.text.ParseException;
import java.util.ArrayList;

public class FuncionarioService {

    // Atributos
    private FuncionarioDAO funcionarioDAO;

    // Construtor

    public FuncionarioService(FuncionarioDAO funcionarioDAO) {
        this.funcionarioDAO = funcionarioDAO;
    }

    // Métodos públicos

    public String listar() throws FuncionarioException, ParseException {
        ArrayList<Funcionario> funcionarios = funcionarioDAO.selecionar();
        String lista = "";
        if (funcionarios.size()>0){
            for (Funcionario funcionario : funcionarios){
                lista += funcionario + "\n";
            }
        }else{
            lista = "Nenhuma pessoa encontrada.";
        }
        return lista;
    }

    public String excluir(Long id)throws FuncionarioException{
        String mensagemErro = validarCampos(Funcionalidade.EXCLUIR,id,null,null,null,null);
        if (!mensagemErro.equals(""))throw new FuncionarioException(mensagemErro);

        if (funcionarioDAO.deletar(id)){
            return "Funcionario excluído com sucesso!";
        }else{
            throw new FuncionarioException("Não foi possível excluir o funcionario! Por favor tente novamente.");
        }
    }

    // Métodos privados

    private String validarCampos(
            Funcionalidade funcionalidade,
            Long id,
            String nomeCompleto,
            String dataNascimentoFormatoBR,
            String documento,
            Long idPessoa,
            String cargo
    ) throws FuncionarioException {
        String erros = "";
        // Verificação de id
        if(funcionalidade == Funcionalidade.ALTERAR || funcionalidade == Funcionalidade.EXCLUIR) {
            if(id == null) {
                erros += "\n- Id é obrigatório.";
            } else if(funcionarioDAO.selecionarPorId(id) == null) {
                erros += "\n- Id não encontrado.";
            }
        }
        // Verificação de outros campos
        if(funcionalidade == Funcionalidade.CADASTRAR || funcionalidade == Funcionalidade.ALTERAR) {
            // Nome completo
            if(nomeCompleto == null || nomeCompleto.trim().equals("")) {
                erros += "\n- Nome completo é obrigatório.";
            }
            // Data de nascimento
            if(dataNascimentoFormatoBR == null || dataNascimentoFormatoBR.trim().equals("")) {
                erros += "\n- Data de nascimento é obrigatória.";
            } else if(!Util.validarDataFormatoBR(dataNascimentoFormatoBR)) {
                erros += "\n- Data de nascimento inválida.";
            }
            // Documento
            if(documento == null || documento.trim().equals("")) {
                erros += "\n- Documento é obrigatório.";
            }

            // Cargo
            if(cargo == null || cargo.trim().equals("")) {
                erros += "\n- Cargo é obrigatório.";
            }
        }

        // Montagem da mensagem de erro
        String mensagemErro = "";
        if(!erros.equals("")) {
            mensagemErro = "Não foi possível " + funcionalidade.name().toLowerCase() + " o funcionario! " +
                    "Erro(s) encontrado(s):" + erros;
        }
        return mensagemErro;
    }

}
