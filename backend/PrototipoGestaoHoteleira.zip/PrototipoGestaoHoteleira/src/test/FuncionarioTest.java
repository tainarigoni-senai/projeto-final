package test;

import exception.FuncionarioException;
import exception.PessoaException;
import model.Funcionario;
import service.FuncionarioService;
import service.PessoaService;

import java.text.ParseException;

public class FuncionarioTest {

    // Atributos
    private FuncionarioService funcionarioService;

    // Construtor
    public FuncionarioTest(FuncionarioService funcionarioService) {
        this.funcionarioService = funcionarioService;
    }

    // Métodos de testes
    public String listar() throws FuncionarioException, ParseException {
        return funcionarioService.listar();
    }
    public String excluir() throws FuncionarioException {
        return funcionarioService.excluir(10L);
    }
}
