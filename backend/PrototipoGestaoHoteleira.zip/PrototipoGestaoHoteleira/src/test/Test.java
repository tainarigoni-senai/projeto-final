package test;

public interface Test {

    public String listar() throws Exception;
    public String cadastrar() throws Exception;
    public String alterar() throws Exception;
    public String excluir() throws Exception;

}
